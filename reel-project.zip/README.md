# 221 Fallen Leaf Drive — social reel

The final export is 1080×1920, 30 fps, H.264/MP4, BT.709 with AAC stereo at 48 kHz, and fast-start metadata. The original colors are retained. The text boxes use solid green #169D53. Landscape shots are fitted at full width on a navy canvas; portrait shots have only their baked-in black side bars removed and receive a gentle 1.2% push-in.

## Re-render or adjust

Requires Python 3 and FFmpeg with libx264, drawtext, zoompan, xfade, and acrossfade filters. No Python packages are required for rendering.

1. Keep the downloaded original as `source.mov` beside `render.py` and `edit.json`.
2. Edit the source in/out times, speed, text strings, or transition duration in `edit.json`. Layout, text position, typography, and colors are defined in `render.py`.
3. After changing clip settings, delete the generated `render-work` and `preview-work` folders so cached clips are regenerated. They contain disposable intermediate files, not source footage.
4. Run `python render.py --preview` for a 540×960 review copy, or `python render.py` for the full-size final export.

The bundled Open Sans fonts keep typography reproducible. Run from an extracted project directory with a simple path. FFmpeg logs are diagnostic and are not needed to re-render.

## Edit decisions

- Keep the opening invitation through 5.9 seconds; omit the subsequent glitchy walking section and dissolve directly into the interior.
- Tighten non-speaking walkthroughs with selective trims and modest 1.15× playback, retaining the original audio with matching tempo adjustments.
- Preserve the kitchen description and closing invitation at normal speed. Adjacent kitchen clips carrying continuous speech join without audio overlaps.
- Use short 0.20-second dissolves and matching audio crossfades at selected shot changes.
- Remove the CapCut end card after 87.3 seconds.
- Keep the price and address within generous Reels/TikTok margins. No heavy filters, blurred background, or extra music were added.

This project zip excludes the original video. A copy of the original remains in the workspace at `/workspace/reel-edit/source.mov`.
