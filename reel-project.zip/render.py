#!/usr/bin/env python3
"""Editable FFmpeg reel project. Run: python render.py [--preview]."""
import json, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parent
cfg = json.loads((ROOT / 'edit.json').read_text())
preview = '--preview' in sys.argv
W,H = (540,960) if preview else (1080,1920)
fps=cfg['fps']; work=ROOT / ('preview-work' if preview else 'render-work'); work.mkdir(exist_ok=True)
def run(cmd):
    subprocess.run(cmd,check=True)
durations=[]
for i,c in enumerate(cfg['clips']):
    duration=round((c['end']-c['start'])/c['speed']*fps)/fps
    durations.append(duration)
    out=work / f'{i:02d}.mp4'
    if out.exists(): continue
    crop='crop=608:1080:656:0,' if c['layout']=='portrait' else ''
    # Gentle 1.2% push-in only on non-speaking portrait walkthroughs.
    motion=''
    if c['layout']=='portrait':
        motion=f",zoompan=z='1+0.012*min(on/{max(1,int(duration*fps)-1)},1)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s={W}x{H}:fps={fps}"
    size=f'scale={W}:{H}' if c['layout']=='portrait' else f'scale={W}:{round(W*9/16/2)*2},pad={W}:{H}:0:(oh-ih)/2:color=0x122029'
    vf=f'{crop}setpts=(PTS-STARTPTS)/{c["speed"]},fps={fps},{size}{motion},setsar=1,format=yuv420p'
    af=f'atempo={c["speed"]},aresample=48000,asetpts=PTS-STARTPTS,apad,atrim=duration={duration}'
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','2','-ss',str(c['start']),'-t',str(c['end']-c['start']),'-i',str(ROOT/cfg['source']),'-vf',vf,'-af',af,'-t',str(duration),'-c:v','libx264','-threads','2','-preset','fast','-crf','16','-c:a','aac','-b:a','192k',str(out)])
    print(f'Prepared clip {i+1}/{len(cfg["clips"])}',flush=True)
filters=[f'[{i}:v]setpts=PTS-STARTPTS,fps={fps},settb=AVTB[in{i}]' for i in range(len(durations))]; v='in0'; a='0:a'; length=durations[0]
for i in range(1,len(durations)):
    d=cfg['clips'][i].get('transition',cfg['transition'])
    nv=f'v{i}';na=f'a{i}'
    if d:
        filters += [f'[{v}][in{i}]xfade=transition=fade:duration={d}:offset={length-d},settb=AVTB[{nv}]',f'[{a}][{i}:a]acrossfade=d={d}:c1=tri:c2=tri[{na}]']
    else:
        filters += [f'[{v}][in{i}]concat=n=2:v=1:a=0,fps={fps},settb=AVTB[{nv}]',f'[{a}][{i}:a]concat=n=2:v=0:a=1[{na}]']
    length += durations[i]-d; v=nv;a=na
font=str(ROOT/'fonts'/'OpenSans-Semibold.ttf')
bold=str(ROOT/'fonts'/'OpenSans-Bold.ttf')
ratio=W/1080
def n(x): return round(x*ratio)
def text(key,y,size,color,fontfile):
    p=work/f'{key}.txt';p.write_text(cfg['text'][key])
    return f"drawtext=fontfile={fontfile}:textfile='{p}':fontsize={n(size)}:fontcolor={color}:x=(w-text_w)/2:y={n(y)}:alpha='min(1,t/0.35)':shadowcolor=black@0.3:shadowx=1:shadowy=2"
style=[f'drawbox=x={n(90)}:y={n(215)}:w={n(900)}:h={n(250)}:color=0x169D53:t=fill',f'drawbox=x={n(90)}:y={n(1360)}:w={n(900)}:h={n(225)}:color=0x169D53:t=fill',f'drawbox=x={n(430)}:y={n(250)}:w={n(220)}:h={n(3)}:color=0xD3BA83:t=fill',text('headline',282,48,'0xD3BA83',bold),text('price',360,62,'0xF8F5ED',bold),text('address',1410,44,'0xF8F5ED',font),text('locality',1480,34,'0xD3BA83',font)]
style += [f'fade=t=out:st={length-0.25}:d=0.25']
filters += [f'[{v}]'+','.join(style)+'[finalv]',f'[{a}]alimiter=limit=0.95:level=false,afade=t=out:st={length-0.3}:d=0.3[finala]']
graph=work/'filters.txt';graph.write_text(';\n'.join(filters))
cmd=['ffmpeg','-hide_banner','-loglevel','warning','-y','-filter_complex_threads','1']
for i in range(len(durations)): cmd+=['-i',str(work/f'{i:02d}.mp4')]
output=ROOT/('preview.mp4' if preview else cfg['output'])
cmd+=['-filter_complex_script',str(graph),'-map','[finalv]','-map','[finala]','-c:v','libx264','-threads','4','-preset','slow','-crf',str(cfg['crf']),'-pix_fmt','yuv420p','-r',str(fps),'-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(output)]
run(cmd)
print(f'Exported {output.name}; timeline {length:.2f}s',flush=True)
